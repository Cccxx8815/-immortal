<p align="center">
  <img width="320" src="https://wpimg.wallstcn.com/9e77e0ae-3018-45a2-bf9f-1a4c88dd300a.svg">
</p>

在线地址：https://panjiachen.github.io/awesome-bookmarks

<!-- 个人 Blog 文章地址：https://panjiachen.github.io/awesome-bookmarks/blog/js.html -->

gitee 访问地址(github.io 有时候在国内访问会很慢)：[awesome-bookmarks](https://panjiachen.gitee.io/awesome-bookmarks/)

**本项目为个人技术收藏集，里面会不定期分享一些作者平时用到的一些库，或者常用的网站和小工具。同时作者也会在上面不定期的写一些简单的博文**

**如果你有好的推荐你可以提 issue 或者 pr 来告诉作者**
