const sidebarMap = [
  { title: '文章', dirname: 'article' },
  { title: '最近阅读', dirname: 'diary' },
  { title: '面试', dirname: 'interview' },
  { title: 'Blog', dirname: 'blog' }
]

module.exports = sidebarMap
