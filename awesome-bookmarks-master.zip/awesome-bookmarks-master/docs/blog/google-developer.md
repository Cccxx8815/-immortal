## 读谷歌开发指南

其实谷歌除了一个分很好的[学习指南](https://developers.google.com/web/fundamentals/?hl=zh-cn)，但很多人都不知道。

DOM(Document Object Mode)
