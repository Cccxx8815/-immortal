const { downloadImages } = require('get-markdown-images')

downloadImages({
  inputDir: './docs/website'
})
